require 'sinatra'
require 'rest_client'
require 'data_mapper'
require 'rubygems'

DataMapper::setup(:default, "sqlite3://#{File.dirname(__FILE__)}/ip_block.db")

class Ip_block
  include DataMapper::Resource
  property :id, Serial
  property :ip, String
  property :ipblock_date, String 

  validates_uniqueness_of :ip
end

DataMapper.finalize
Ip_block.auto_upgrade!

before do
  ip = Ip_block.first(:ip => request.env['REMOTE_ADDR'].split(',').first)
 if !ip.nil?
  redirect 'http://www.warning.or.kr/'
end
end

get '/' do
	erb:index
end

get '/admin' do
	@ip = Ip_block.all
	erb:admin
end

get '/ip_del/:ip_id' do
  ip = Ip_block.first(:id => params[:ip_id])
  ip.destroy
  redirect '/admin'
end

post '/ip_block' do
	ip = Ip_block.new
	ip.ip = params[:ip]
	ip.ipblock_date = Time.now
	ip.save
	redirect '/admin'
end